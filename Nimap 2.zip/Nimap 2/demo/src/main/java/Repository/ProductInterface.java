package Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import Model.Product;

public interface ProductInterface extends JpaRepository <Product,Integer> {

}
