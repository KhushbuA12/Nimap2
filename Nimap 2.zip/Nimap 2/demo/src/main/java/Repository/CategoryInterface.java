package Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Model.Category;
@Repository
public interface CategoryInterface extends JpaRepository<Category,Integer>  {

}
