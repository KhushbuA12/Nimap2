package Service;

import java.util.List;
import java.util.Optional;

import Model.Category;
import Repository.CategoryInterface;

public interface CategoryService extends CategoryInterface {
    public List<Category> getAllCategories();
    public Optional<Category> getCategoriesById(int id);
    public String updateCategories(int id,Category category);
    public String deleteCategories(int id);
    public String createCategory(Category category);


}
